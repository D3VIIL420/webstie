// ===== MuskanHost � Main Script =====
const API = 'https://api.muskanhost.com';
console.log("MuskanHost Loaded ");

// -------- Signup --------
async function signup(e){
  e.preventDefault();
  const name = document.getElementById('sname').value;
  const email = document.getElementById('semail').value;
  const password = document.getElementById('spass').value;
  if(!name||!email||!password){ alert("Please fill all fields"); return; }

  try {
    const res = await fetch(`${API}/api/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('mh_token', data.token);
      localStorage.setItem('mh_user', JSON.stringify(data.user));
      alert("Account // ===== MuskanHost � Main Script =====
const API = 'https://api.muskanhost.com';
console.log("MuskanHost Loaded ");

// -------- Signup --------
async function signup(e){
  e.preventDefault();
  const name = document.getElementById('sname').value;
  const email = document.getElementById('semail').value;
  const password = document.getElementById('spass').value;
  if(!name||!email||!password){ alert("Please fill all fields"); return; }

  try {
    const res = await fetch(`${API}/api/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('mh_token', data.token);
      localStorage.setItem('mh_user', JSON.stringify(data.user));
      alert("Account created! Please login now");
      window.location.href = "login.html";
    } else alert(data.error || 'Signup failed');
  } catch (err) {
    localStorage.setItem('mh_user', JSON.stringify({name,email,pass:password,coins:0,money:0,plan:'free'}));
    alert("Account created (demo mode)!");
    window.location.href = "login.html";
  }
}

// -------- Login --------
async function login(e){
  e.preventDefault();
  const email = document.getElementById('lemail').value;
  const password = document.getElementById('lpass').value;

  try {
    const res = await fetch(`${API}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('mh_token', data.token);
      localStorage.setItem('mh_user', JSON.stringify(data.user));
      localStorage.setItem('mh_logged','1');
      window.location.href = "dashboard.html";
    } else alert(data.error || 'Login failed');
  } catch (err) {
    const user = JSON.parse(localStorage.getItem('mh_user'));
    if(user && user.email===email && user.pass===password){
      localStorage.setItem('mh_logged','1');
      window.location.href = "dashboard.html";
    } else alert("Wrong email or password");
  }
}

// -------- Logout --------
function logout(){
  localStorage.removeItem('mh_logged');
  localStorage.removeItem('mh_token');
  window.location.href = "index.html";
}

// -------- Coins --------
function addCoins(n){
  const user = JSON.parse(localStorage.getItem('mh_user')) || {coins:0,money:0};
  user.coins = (user.coins||0) + n;
  localStorage.setItem('mh_user', JSON.stringify(user));
  updateCoins();
  alert(` You earned ${n} coins! Total: ${user.coins}`);
}

function dailyReward(){
  const last = localStorage.getItem('mh_last_daily');
  const today = new Date().toDateString();
  if(last===today){ alert("You already claimed today's reward. Come back tomorrow!"); return; }
  localStorage.setItem('mh_last_daily', today);
  addCoins(50);
}

function updateCoins(){
  const user = JSON.parse(localStorage.getItem('mh_user')) || {coins:0,money:0};
  document.querySelectorAll('.coin-count').forEach(el=>el.textContent = user.coins || 0);
  document.querySelectorAll('.money-count').forEach(el=>el.textContent = (user.money||0).toFixed(2));
}

// -------- Ads --------
async function watchAd(){
  try {
    const token = localStorage.getItem('mh_token');
    const res = await fetch(`${API}/api/ads/watch`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ adId: 'ad1' })
    });
    const data = await res.json();
    if (data.success) {
      alert(` Earned ${data.coinsEarned} coins + $${data.moneyEarned}`);
      updateCoins();
    } else alert(data.error);
  } catch {
    const user = JSON.parse(localStorage.getItem('mh_user')) || {coins:0,money:0};
    user.coins = (user.coins||0) + 10;
    user.money = (user.money||0) + 0.01;
    localStorage.setItem('mh_user', JSON.stringify(user));
    updateCoins();
    alert(" Ad watched � earned $0.01 (Payoneer transfer)");
  }
}

// -------- Contact --------
function sendContact(e){
  e.preventDefault();
  alert(" Message sent! Nasiir Aliiw will contact you soon.");
  e.target.reset();
}

// -------- Deploy --------
async function deployBot(e){
  e.preventDefault();
  const form = e.target;
  const name = form.querySelector('input[type="text"]').value;
  const runtime = form.querySelector('select').value;
  const token = form.querySelector('input[type="password"]').value;

  try {
    const res = await fetch(`${API}/api/bot/create`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('mh_token')}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, runtime, token })
    });
    const data = await res.json();
    if (data.success) alert(" Bot deployed successfully! Uptime engine will keep it 24/7 online.");
    else alert(data.error);
  } catch {
    alert(" Bot is deploying... 24/7 uptime enabled!");
  }
}

// -------- PWA --------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js')
      .then(reg => console.log(' PWA registered'))
      .catch(err => console.log(' SW failed:', err));
  });
}

let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const installBtn = document.getElementById('installApp');
  if (installBtn) installBtn.style.display = 'inline-flex';
});

function installApp() {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  deferredPrompt.userChoice.then((choice) => {
    if (choice.outcome === 'accepted') console.log(' App installed');
    deferredPrompt = null;
  });
}

window.onload = updateCoins;! Please login now");
      window.location.href = "login.html";
    } else alert(data.error || 'Signup failed');
  } catch (err) {
    localStorage.setItem('mh_user', JSON.stringify({name,email,pass:password,coins: