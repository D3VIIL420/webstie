// ===== MuskanHost Ad Config =====
const AD_CONFIG = {
  adsense: {
    enabled: false,
    clientId: 'ca-pub-XXXXXXXXXXXXXXXX',
    slots: { banner: '1234567890', sidebar: '0987654321', reward: '1122334455' }
  },
  adsterra: {
    enabled: true,
    directLink: 'https://your-adsterra-direct-link.com',
    bannerKey: 'your-adsterra-banner-key'
  }
};

function loadAdSense() {
  if (!AD_CONFIG.adsense.enabled) return;
  const script = document.createElement('script');
  script.async = true;
  script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + AD_CONFIG.adsense.clientId;
  script.crossOrigin = 'anonymous';
  document.head.appendChild(script);
}

function showBannerAd(containerId, position = 'banner') {
  const container = document.getElementById(containerId);
  if (!container) return;
  if (AD_CONFIG.adsense.enabled) {
    container.innerHTML = `<ins class="adsbygoogle" style="display:block" data-ad-client="${AD_CONFIG.adsense.clientId}" data-ad-slot="${AD_CONFIG.adsense.slots[position]}" data-ad-format="auto" data-full-width-responsive="true"></ins>`;
    (adsbygoogle = window.adsbygoogle || []).push({});
  } else if (AD_CONFIG.adsterra.enabled) {
    container.innerHTML = `<div style="text-align:center; padding:20px; background:var(--bg-2); border-radius:12px; border:1px dashed var(--border);"><p style="color:var(--text-muted); font-size:13px;">📢 Ad Space — Adsterra</p></div>`;
  }
}

async function showRewardedAd() {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.style.cssText = `position:fixed; inset:0; background:rgba(0,0,0,0.95); display:flex; flex-direction:column; align-items:center; justify-content:center; z-index:9999; color:#fff; font-family:Inter,sans-serif;`;
    let seconds = 30;
    overlay.innerHTML = `<div style="text-align:center;"><h2>📢 Ad Playing</h2><div style="width:200px; height:200px; background:linear-gradient(135deg,#8b5cf6,#06b6d4); border-radius:20px; display:flex; align-items:center; justify-content:center; font-size:60px; margin:20px auto;">🎬</div><p>Earn +10 🪙 + $0.01</p><p style="font-size:48px; font-weight:800; color:#8b5cf6;" id="adTimer">${seconds}</p></div>`;
    document.body.appendChild(overlay);
    const timer = setInterval(() => {
      seconds--;
      const el = document.getElementById('adTimer');
      if (el) el.textContent = seconds;
      if (seconds <= 0) {
        clearInterval(timer);
        overlay.remove();
        if (typeof addCoins === 'function') addCoins(10);
        resolve({ success: true });
      }
    }, 1000);
  });
}

loadAdSense();
console.log('✅ Ads module loaded');