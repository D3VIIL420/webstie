const CACHE_NAME = 'muskanhost-v1';
const ASSETS = [
  'index.html','login.html','signup.html','dashboard.html','plans.html',
  'earn.html','ads.html','deploy.html','contact.html','terms.html','privacy.html','uptime.html',
  'style.css','script.js','ads-config.js','manifest.json'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(res => {
      return caches.open(CACHE_NAME).then(cache => {
        if (e.request.url.startsWith(self.location.origin)) cache.put(e.request, res.clone());
        return res;
      });
    }).catch(() => caches.match('index.html')))
  );
});