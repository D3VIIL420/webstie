const express = require('express');
const auth = require('../middleware/auth');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const router = express.Router();

router.post('/request', auth, async (req, res) => {
  const MIN = parseFloat(process.env.PAYONEER_MIN_WITHDRAWAL) || 5;
  const user = await User.findById(req.user._id);

  if (user.money < MIN) {
    return res.status(400).json({ error: `Minimum withdrawal is $${MIN}. You have $${user.money.toFixed(2)}` });
  }

  const amount = user.money;

  await Transaction.create({
    user: user._id,
    type: 'payout',
    amount,
    status: 'pending',
    method: 'payoneer',
    details: `Payoneer: ${process.env.PAYONEER_EMAIL}`
  });

  user.money = 0;
  await user.save();

  res.json({
    success: true,
    message: `Payout request of $${amount.toFixed(2)} submitted. Nasiir Aliiw will process it within 3-5 days.`,
    payoneer: process.env.PAYONEER_EMAIL,
    whatsapp: process.env.OWNER_WHATSAPP
  });
});

router.get('/history', auth, async (req, res) => {
  const txs = await Transaction.find({ user: req.user._id, type: 'payout' }).sort({ createdAt: -1 });
  res.json(txs);
});

module.exports = router;