const express = require('express');
const auth = require('../middleware/auth');
const Bot = require('../models/Bot');
const UptimeLog = require('../models/UptimeLog');
const {
  checkBot, getUptimeStats, handleExternalPing
} = require('../services/uptimeEngine');
const {
  startPterodactylServer, stopPterodactylServer, restartPterodactylServer
} = require('../services/pterodactyl');
const router = express.Router();

router.get('/stats/:botId', auth, async (req, res) => {
  try {
    const bot = await Bot.findOne({ _id: req.params.botId, user: req.user._id });
    if (!bot) return res.status(404).json({ error: 'Bot not found' });
    const stats = await getUptimeStats(bot._id, 30);
    res.json({ success: true, bot: bot.name, ...stats });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/all', auth, async (req, res) => {
  try {
    const bots = await Bot.find({ user: req.user._id });
    const stats =