const express = require('express');
const auth = require('../middleware/auth');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const router = express.Router();

router.get('/me', auth, async (req, res) => {
  const user = await User.findById(req.user._id).select('-password');
  res.json(user);
});

router.post('/daily', auth, async (req, res) => {
  const user = await User.findById(req.user._id);
  const today = new Date().toDateString();
  const last = user.lastDailyClaim ? user.lastDailyClaim.toDateString() : null;

  if (last === today) return res.status(400).json({ error: 'Already claimed today' });

  user.coins += 50;
  user.lastDailyClaim = new Date();
  await user.save();

  await Transaction.create({ user: user._id, type: 'daily_bonus', coins: 50 });
  res.json({ success: true, coins: user.coins, earned: 50 });
});

router.get('/transactions', auth, async (req, res) => {
  const txs = await Transaction.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(50);
  res.json(txs);
});

module.exports = router;