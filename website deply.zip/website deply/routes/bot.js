const express = require('express');
const auth = require('../middleware/auth');
const Bot = require('../models/Bot');
const { createPterodactylServer, deletePterodactylServer } = require('../services/pterodactyl');
const router = express.Router();

router.post('/create', auth, async (req, res) => {
  try {
    const { name, runtime, token } = req.body;
    if (!name || !runtime) return res.status(400).json({ error: 'Name and runtime required' });

    const botCount = await Bot.countDocuments({ user: req.user._id });
    if (req.user.plan === 'free' && botCount >= 1) {
      return res.status(400).json({ error: 'Free plan allows 1 bot only. Upgrade to add more.' });
    }

    const ptero = await createPterodactylServer({
      name: `MH-${req.user._id.toString().slice(-6)}-${name}`,
      user: req.user,
      runtime,
      token
    });

    const bot = await Bot.create({
      user: req.user._id,
      name,
      runtime,
      pterodactylId: ptero.id,
      pterodactylUuid: ptero.uuid,
      status: 'running'
    });

    console.log(`📥 Keep-alive + 24/7 uptime enabled for "${name}"`);
    res.status(201).json({ success: true, bot });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/list', auth, async (req, res) => {
  const bots = await Bot.find({ user: req.user._id });
  res.json(bots);
});

router.delete('/:id', auth, async (req, res) => {
  const bot = await Bot.findOne({ _id: req.params.id, user: req.user._id });
  if (!bot) return res.status(404).json({ error: 'Bot not found' });
  if (bot.pterodactylId) await deletePterodactylServer(bot.pterodactylId);
  await bot.deleteOne();
  res.json({ success: true, message: 'Bot deleted' });
});

module.exports = router;