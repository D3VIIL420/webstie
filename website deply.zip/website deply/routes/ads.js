const express = require('express');
const auth = require('../middleware/auth');
const User = require('../models/User');
const Ad = require('../models/Ad');
const Transaction = require('../models/Transaction');
const router = express.Router();

router.post('/watch', auth, async (req, res) => {
  const user = await User.findById(req.user._id);
  const now = new Date();

  if (user.lastAdReset.toDateString() !== now.toDateString()) {
    user.adsWatchedToday = 0;
    user.lastAdReset = now;
  }

  if (user.adsWatchedToday >= 100) {
    return res.status(400).json({ error: 'Daily ad limit reached (100 ads/day)' });
  }

  const COINS = parseInt(process.env.COINS_PER_AD) || 10;
  const USD = parseFloat(process.env.USD_PER_AD) || 0.01;

  user.coins += COINS;
  user.money += USD;
  user.adsWatchedToday += 1;
  await user.save();

  await Ad.create({ user: user._id, adId: req.body.adId || 'default', coinsEarned: COINS, moneyEarned: USD });
  await Transaction.create({ user: user._id, type: 'ad_reward', coins: COINS, amount: USD });

  res.json({
    success: true,
    coinsEarned: COINS,
    moneyEarned: USD,
    totalCoins: user.coins,
    totalMoney: user.money.toFixed(2),
    adsToday: user.adsWatchedToday
  });
});

module.exports = router;