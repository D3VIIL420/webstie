# MuskanHost — Keep-Alive Script (Python bots)
import os
import time
import threading
import urllib.request
from http.server import HTTPServer, BaseHTTPRequestHandler

KEEP_ALIVE_URL = os.getenv('KEEP_ALIVE_URL', 'https://api.muskanhost.com/api/uptime/keepalive')
BOT_ID = os.getenv('BOT_ID', '')
PING_INTERVAL = 5 * 60

def ping():
    if not BOT_ID:
        print('[Keep-Alive] BOT_ID not set')
        return
    try:
        url = f'{KEEP_ALIVE_URL}/{BOT_ID}'
        with urllib.request.urlopen(url, timeout=10) as res:
            print(f'[Keep-Alive] ✅ Ping sent — {res.status}')
    except Exception as e:
        print(f'[Keep-Alive] ❌ Ping failed: {e}')

def ping_loop():
    time.sleep(30)
    while True:
        ping()
        time.sleep(PING_INTERVAL)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'MuskanHost Bot - Online 24/7')
    def log_message(self, *args): pass

def start_http():
    port = int(os.getenv('PORT', 3000))
    server = HTTPServer(('0.0.0.0', port), Handler)
    print(f'[Keep-Alive] 🌐 HTTP server on port {port}')
    server.serve_forever()

if __name__ == '__main__':
    threading.Thread(target=ping_loop, daemon=True).start()
    print('[Keep-Alive] 🚀 MuskanHost keep-alive started')
    start_http()