// MuskanHost — Keep-Alive Script (Node.js bots)
const https = require('https');
const http = require('http');

const KEEP_ALIVE_URL = process.env.KEEP_ALIVE_URL || 'https://api.muskanhost.com/api/uptime/keepalive';
const BOT_ID = process.env.BOT_ID || '';
const PING_INTERVAL = 5 * 60 * 1000; // 5 min

function ping() {
  if (!BOT_ID) return console.log('[Keep-Alive] BOT_ID not set');
  const url = `${KEEP_ALIVE_URL}/${BOT_ID}`;
  const client = url.startsWith('https') ? https : http;
  client.get(url, (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => console.log(`[Keep-Alive] ✅ Ping ${res.statusCode} at ${new Date().toISOString()}`));
  }).on('error', (err) => console.error('[Keep-Alive] ❌ Ping failed:', err.message));
}

setTimeout(ping, 30 * 1000);
setInterval(ping, PING_INTERVAL);

console.log('[Keep-Alive] 🚀 MuskanHost keep-alive started');

// HTTP server for external uptime monitors
const PORT = process.env.PORT || 3000;
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('MuskanHost Bot — Online 24/7');
});
server.listen(PORT, () => console.log(`[Keep-Alive] 🌐 HTTP server on port ${PORT}`));

module.exports = { ping, server };