const mongoose = require('mongoose');

const uptimeLogSchema = new mongoose.Schema({
  bot: { type: mongoose.Schema.Types.ObjectId, ref: 'Bot', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  status: { type: String, enum: ['online','offline','restarting','warning'], default: 'online' },
  ping: { type: Number, default: 0 },
  error: { type: String },
  checkType: { type: String, enum: ['auto','external','manual'], default: 'auto' },
  checkedAt: { type: Date, default: Date.now }
});

uptimeLogSchema.index({ bot: 1, checkedAt: -1 });

module.exports = mongoose.model('UptimeLog', uptimeLogSchema);