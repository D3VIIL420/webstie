const mongoose = require('mongoose');

const botSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  runtime: { type: String, required: true },
  pterodactylId: { type: String },
  pterodactylUuid: { type: String },
  status: { type: String, enum: ['creating','running','stopped','suspended'], default: 'creating' },
  ram: { type: Number, default: 256 },
  cpu: { type: Number, default: 100 },
  disk: { type: Number, default: 512 },
  env: { type: Map, of: String },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Bot', botSchema);