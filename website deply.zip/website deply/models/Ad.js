const mongoose = require('mongoose');

const adSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  adId: { type: String, required: true },
  coinsEarned: { type: Number, default: 10 },
  moneyEarned: { type: Number, default: 0.01 },
  watchedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Ad', adSchema);