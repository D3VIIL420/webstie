const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6 },
  coins: { type: Number, default: 0 },
  money: { type: Number, default: 0 },
  plan: { type: String, enum: ['free','starter','pro'], default: 'free' },
  planExpiry: { type: Date },
  role: { type: String, enum: ['user','admin'], default: 'user' },
  referralCode: { type: String, unique: true },
  referredBy: { type: String },
  lastDailyClaim: { type: Date },
  adsWatchedToday: { type: Number, default: 0 },
  lastAdReset: { type: Date, default: Date.now },
  isVerified: { type: Boolean, default: false }
}, { timestamps: true });

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function(candidate) {
  return await bcrypt.compare(candidate, this.password);
};

userSchema.pre('save', function(next) {
  if (!this.referralCode) {
    this.referralCode = 'MH' + Math.random().toString(36).substring(2, 10).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('User', userSchema);