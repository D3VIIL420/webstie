const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: { type: String, enum: ['ad_reward','daily_bonus','referral','payout','purchase'], required: true },
  coins: { type: Number, default: 0 },
  amount: { type: Number, default: 0 },
  status: { type: String, enum: ['pending','completed','rejected'], default: 'completed' },
  method: { type: String, default: 'payoneer' },
  details: { type: String },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Transaction', transactionSchema);