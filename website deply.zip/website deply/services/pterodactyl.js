const axios = require('axios');

const ptero = axios.create({
  baseURL: `${process.env.PTERO_URL}/api/application`,
  headers: {
    'Authorization': `Bearer ${process.env.PTERO_API_KEY}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

const pteroClient = axios.create({
  baseURL: `${process.env.PTERO_URL}/api/client`,
  headers: {
    'Authorization': `Bearer ${process.env.PTERO_CLIENT_KEY}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

async function getOrCreatePteroUser(user) {
  try {
    const search = await ptero.get(`/users?filter[email]=${user.email}`);
    if (search.data.data.length > 0) return search.data.data[0];

    const created = await ptero.post('/users', {
      email: user.email,
      username: user.email.split('@')[0] + Math.floor(Math.random() * 999),
      first_name: user.name.split(' ')[0] || 'User',
      last_name: user.name.split(' ')[1] || 'MH',
      password: Math.random().toString(36).slice(-12) + 'Aa1!'
    });
    return created.data.attributes;
  } catch (err) {
    throw new Error('Pterodactyl user error: ' + err.message);
  }
}

async function createPterodactylServer({ name, user, runtime, token }) {
  const pteroUser = await getOrCreatePteroUser(user);

  const payload = {
    name,
    user: pteroUser.id,
    egg: parseInt(process.env.PTERO_EGG_ID),
    docker_image: getDockerImage(runtime),
    startup: getStartupCommand(runtime),
    environment: {
      BOT_TOKEN: token || '',
      KEEP_ALIVE_URL: `${process.env.API_URL}/api/uptime/keepalive`,
      ...getDefaultEnv(runtime)
    },
    limits: { memory: 256, swap: 0, disk: 512, io: 500, cpu: 100 },
    feature_limits: { databases: 2, backups: 2, allocations: 1 },
    deploy: { locations: [parseInt(process.env.PTERO_LOCATION_ID)], dedicated_ip: false, port_range: [] }
  };

  const res = await ptero.post('/servers', payload);
  return res.data.attributes;
}

async function deletePterodactylServer(id) {
  await ptero.delete(`/servers/${id}`);
}

async function restartPterodactylServer(uuid) {
  try {
    await pteroClient.post(`/servers/${uuid}/power`, { signal: 'restart' });
    return true;
  } catch (err) {
    try {
      await pteroClient.post(`/servers/${uuid}/power`, { signal: 'stop' });
      await new Promise(r => setTimeout(r, 3000));
      await pteroClient.post(`/servers/${uuid}/power`, { signal: 'start' });
      return true;
    } catch (e) {
      throw new Error('Restart failed: ' + e.message);
    }
  }
}

async function startPterodactylServer(uuid) {
  await pteroClient.post(`/servers/${uuid}/power`, { signal: 'start' });
}

async function stopPterodactylServer(uuid) {
  await pteroClient.post(`/servers/${uuid}/power`, { signal: 'stop' });
}

async function getServerStatus(uuid) {
  try {
    const res = await pteroClient.get(`/servers/${uuid}/resources`);
    const state = res.data.attributes.current_state;
    if (state === 'running') return 'running';
    if (state === 'starting') return 'starting';
    if (state === 'stopping') return 'stopping';
    return 'offline';
  } catch (err) {
    return 'offline';
  }
}

function getDockerImage(runtime) {
  const images = {
    'Node.js': 'ghcr.io/parkervcp/yolks:nodejs_18',
    'Python': 'ghcr.io/parkervcp/yolks:python_3.11',
    'Java': 'ghcr.io/parkervcp/yolks:java_17',
    'PHP': 'ghcr.io/parkervcp/yolks:php_8.2',
    'Go': 'ghcr.io/parkervcp/yolks:go_1.20',
    'Rust': 'ghcr.io/parkervcp/yolks:rust_latest'
  };
  return images[runtime] || images['Node.js'];
}

function getStartupCommand(runtime) {
  const cmds = {
    'Node.js': 'node keep-alive.js && npm start',
    'Python': 'python keep-alive.py && python main.py',
    'Java': 'java -jar bot.jar',
    'PHP': 'php bot.php',
    'Go': './bot',
    'Rust': './target/release/bot'
  };
  return cmds[runtime] || 'npm start';
}

function getDefaultEnv(runtime) {
  return {
    NODE_ENV: 'production',
    PYTHONUNBUFFERED: '1',
    AUTO_RESTART: 'true',
    UPTIME_MONITOR: 'true'
  };
}

module.exports = {
  createPterodactylServer,
  deletePterodactylServer,
  restartPterodactylServer,
  startPterodactylServer,
  stopPterodactylServer,
  getServerStatus
};