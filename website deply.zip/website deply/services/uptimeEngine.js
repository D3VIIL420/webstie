// ===== MuskanHost — 24/7 Uptime Engine =====
const Bot = require('../models/Bot');
const UptimeLog = require('../models/UptimeLog');
const {
  restartPterodactylServer,
  getServerStatus
} = require('./pterodactyl');

const CONFIG = {
  PING_INTERVAL: 60 * 1000,
  MAX_RETRIES: 3,
  AUTO_RESTART: true,
  OFFLINE_THRESHOLD: 2,
  START_DELAY: 10 * 1000
};

const failureCount = new Map();

async function checkBot(bot) {
  try {
    const pteroStatus = await getServerStatus(bot.pterodactylUuid);
    const start = Date.now();
    const ping = Date.now() - start;

    let status = 'online';
    if (pteroStatus === 'offline' || pteroStatus === 'stopped') status = 'offline';
    else if (pteroStatus === 'starting' || pteroStatus === 'installing') status = 'warning';

    if (status === 'offline') {
      const fails = (failureCount.get(bot._id.toString()) || 0) + 1;
      failureCount.set(bot._id.toString(), fails);

      await UptimeLog.create({
        bot: bot._id, user: bot.user, status: 'offline',
        ping, error: `Consecutive failures: ${fails}`, checkType: 'auto'
      });

      if (fails >= CONFIG.OFFLINE_THRESHOLD && CONFIG.AUTO_RESTART) {
        console.log(`🚨 Bot ${bot.name} offline ${fails}x — restarting...`);
        await attemptRestart(bot);
        failureCount.set(bot._id.toString(), 0);
      }
    } else {
      failureCount.set(bot._id.toString(), 0);
      await UptimeLog.create({
        bot: bot._id, user: bot.user,
        status: status === 'warning' ? 'warning' : 'online',
        ping, checkType: 'auto'
      });
    }

    return { botId: bot._id, status, ping };
  } catch (err) {
    await UptimeLog.create({
      bot: bot._id, user: bot.user, status: 'offline',
      error: err.message, checkType: 'auto'
    });
    const fails = (failureCount.get(bot._id.toString()) || 0) + 1;
    failureCount.set(bot._id.toString(), fails);
    if (fails >= CONFIG.OFFLINE_THRESHOLD && CONFIG.AUTO_RESTART) {
      await attemptRestart(bot);
      failureCount.set(bot._id.toString(), 0);
    }
    return { botId: bot._id, status: 'offline', error: err.message };
  }
}

async function attemptRestart(bot) {
  for (let i = 1; i <= CONFIG.MAX_RETRIES; i++) {
    try {
      console.log(`🔄 Restart attempt ${i}/${CONFIG.MAX_RETRIES} for "${bot.name}"`);
      await restartPterodactylServer(bot.pterodactylUuid);

      await UptimeLog.create({ bot: bot._id, user: bot.user, status: 'restarting', checkType: 'auto' });

      await new Promise(r => setTimeout(r, 5000));
      const status = await getServerStatus(bot.pterodactylUuid);

      if (status === 'running') {
        console.log(`✅ Bot "${bot.name}" restarted successfully`);
        await UptimeLog.create({ bot: bot._id, user: bot.user, status: 'online', checkType: 'auto' });
        return true;
      }
    } catch (err) {
      console.error(`❌ Restart ${i} failed for "${bot.name}":`, err.message);
    }
  }
  console.error(`💀 Bot "${bot.name}" failed after ${CONFIG.MAX_RETRIES} attempts`);
  return false;
}

async function checkAllBots() {
  try {
    const bots = await Bot.find({ status: { $in: ['running','stopped','suspended','creating'] } });
    if (bots.length === 0) return;

    console.log(`⏰ Uptime engine: checking ${bots.length} bots...`);
    const results = await Promise.all(bots.map(b => checkBot(b)));
    const online = results.filter(r => r.status === 'online').length;
    const offline = results.filter(r => r.status === 'offline').length;
    console.log(`✅ Check done — ${online} online · ${offline} offline`);
    return results;
  } catch (err) {
    console.error('❌ Uptime engine error:', err.message);
  }
}

function startUptimeEngine() {
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log('⏰ MuskanHost Uptime Engine Started');
  console.log(`   • Interval: ${CONFIG.PING_INTERVAL / 1000} seconds`);
  console.log(`   • Auto-Restart: ${CONFIG.AUTO_RESTART ? 'ENABLED' : 'DISABLED'}`);
  console.log(`   • Max Retries: ${CONFIG.MAX_RETRIES}`);
  console.log('═══════════════════════════════════════════');
  console.log('');

  setTimeout(checkAllBots, CONFIG.START_DELAY);
  setInterval(checkAllBots, CONFIG.PING_INTERVAL);
}

async function getUptimeStats(botId, days = 30) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const logs = await UptimeLog.find({ bot: botId, checkedAt: { $gte: since } });

  const total = logs.length;
  const online = logs.filter(l => l.status === 'online').length;
  const uptime = total > 0 ? ((online / total) * 100).toFixed(2) : 100;

  const daily = [];
  for (let i = days - 1; i >= 0; i--) {
    const dayStart = new Date();
    dayStart.setDate(dayStart.getDate() - i);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart);
    dayEnd.setHours(23, 59, 59, 999);

    const dayLogs = logs.filter(l => l.checkedAt >= dayStart && l.checkedAt <= dayEnd);
    const dayOnline = dayLogs.filter(l => l.status === 'online' || l.status === 'warning').length;
    const dayTotal = dayLogs.length;
    const percent = dayTotal > 0 ? (dayOnline / dayTotal) * 100 : 100;

    daily.push({
      date: dayStart.toISOString().split('T')[0],
      percent: parseFloat(percent.toFixed(2)),
      status: percent >= 99 ? 'online' : percent >= 90 ? 'warning' : 'offline'
    });
  }

  return { uptime: parseFloat(uptime), total, online, daily };
}

async function handleExternalPing(botId) {
  const bot = await Bot.findById(botId);
  if (!bot) return null;
  failureCount.set(bot._id.toString(), 0);
  await UptimeLog.create({
    bot: bot._id, user: bot.user, status: 'online', ping: 0, checkType: 'external'
  });
  return { status: 'online', bot: bot.name };
}

module.exports = {
  checkBot, checkAllBots, startUptimeEngine, attemptRestart,
  getUptimeStats, handleExternalPing, CONFIG
};