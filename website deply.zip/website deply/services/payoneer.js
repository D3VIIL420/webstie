const PAYONEER_EMAIL = process.env.PAYONEER_EMAIL;

async function processPayout(transaction) {
  console.log(`💸 Payout pending: $${transaction.amount} → ${transaction.user.email}`);
  return { status: 'pending', method: 'payoneer', email: PAYONEER_EMAIL };
}

module.exports = { processPayout };