const User = require('../models/User');
const Transaction = require('../models/Transaction');

async function awardCoins(userId, coins, type = 'ad_reward', amount = 0) {
  const user = await User.findById(userId);
  if (!user) throw new Error('User not found');
  user.coins += coins;
  if (amount > 0) user.money += amount;
  await user.save();
  await Transaction.create({ user: userId, type, coins, amount });
  return user;
}

async function deductCoins(userId, coins) {
  const user = await User.findById(userId);
  if (!user || user.coins < coins) throw new Error('Insufficient coins');
  user.coins -= coins;
  await user.save();
  return user;
}

module.exports = { awardCoins, deductCoins };