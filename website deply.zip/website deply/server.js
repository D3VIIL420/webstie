require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const { startUptimeEngine } = require('./services/uptimeEngine');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB Connected');
    startUptimeEngine();
  })
  .catch(err => console.error('❌ MongoDB Error:', err));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/user', require('./routes/user'));
app.use('/api/bot', require('./routes/bot'));
app.use('/api/ads', require('./routes/ads'));
app.use('/api/payout', require('./routes/payout'));
app.use('/api/uptime', require('./routes/uptime'));

app.get('/', (req, res) => {
  res.json({
    name: 'MuskanHost API',
    owner: process.env.OWNER_NAME,
    status: 'online',
    uptime: process.uptime(),
    contact: process.env.OWNER_EMAIL
  });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Server error' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 MuskanHost Backend running on port ${PORT}`);
  console.log(`👤 Owner: ${process.env.OWNER_NAME}`);
});